from gunicorn.http.errors import InvalidHTTPVersion
request = InvalidHTTPVersion